# 1 задача
x = input()
z = (2)
print(x, z)

# 2 задача
b = int(input())
n = 2 + b
print(n)

# 3 задача
age = int(input('Введите ваш возраст'))
if age < 18:
    print('Извините, пользование данным ресурсом только с 18 лет')
else:
    print('Доступ разрешён')

